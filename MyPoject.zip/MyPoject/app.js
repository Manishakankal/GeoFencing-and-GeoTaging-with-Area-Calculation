const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const User = require('./models/User');

const app = express();
const PORT = 3000;

// MongoDB Connection
mongoose.connect('mongodb+srv://manukankal:qD48DsjkVgnoCOyo@cluster0.uqc44i7.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0').then(() => console.log('MongoDB Connected'))
    .catch(err => console.error(err));

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

app.use(session({
    secret: 'mySecretKey123',
    resave: false,
    saveUninitialized: false
}));

// Middleware to protect routes
function requireLogin(req, res, next) {
    if (req.session.userId) {
        next();
    } else {
        res.redirect('/login');
    }
}

// Routes
app.get('/', requireLogin, (req, res) => {
    res.render('index');
});



app.get('/login', (req, res) => {
    res.render('login', { error: null });
});



app.get('/register', (req, res) => {
    res.render('register', { error: null });
});


// In your server.js or routes file

app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;

    try {
        // 1. CHECK IF USER ALREADY EXISTS
        const existingUser = await User.findOne({ email: email });

        if (existingUser) {
            // If the user is found, redirect back with an error message
            // This is the key part for showing the popup
            return res.redirect('/register?error=exists');
        }

        // 2. If user does not exist, proceed with creating a new user
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({
            name: name,
            email: email,
            password: hashedPassword
        });

        await newUser.save();

        // 3. (Optional but good UX) Log the user in immediately after registration
        req.session.userId = newUser._id;

        // 4. Redirect to the main app with a success message
        res.redirect('/');

    } catch (err) {
        console.error(err);
        // Handle other potential errors (e.g., database connection issue)
        res.redirect('/register?error=server');
    }
});

// In your server.js file

app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });

        // If user doesn't exist OR the password doesn't match...
        if (!user || !(await bcrypt.compare(password, user.password))) {
            // THIS IS THE IMPORTANT PART:
            // Send the user back to the login page.
            // Add "?login=failed" to the URL.
            return res.redirect('/login?login=failed');
        }

        // If login is successful...
        req.session.userId = user._id;
        res.redirect('/'); // Redirect to your main app

    } catch (err) {
        console.error(err);
        res.redirect('/login?error=server'); // Handle server errors
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
